[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=500&height=60&lines=HOLLA+WELCOME+TO+THIS+REPO!)](https://git.io/typing-svg)

   [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=FORK+AND+MAYBE+GIVE+US+A+STAR)](https://git.io/typing-svg)





<a
href="https://whatsapp.com/channel/0029ValVRdpI1rcfS1rAJq3h">
 <img alt="RE-JEONG-V4" height="300" src="https://telegra.ph/file/019207dd7bf306d343b7e.jpg">
  
</p>
<p align="center">
<a href="https://github.com/Guanxii1"><img title="Author" src="https://img.shields.io/badge/Re-Jeong-v4-black?style=for-the-badge&logo=twitter"></a>
<p/>
<p align="center">
<a href="https://github.com/Guanxii1?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Guanxii1?label=Followers&style=social"></a>
<a href="https://github.com/Guanxii1/Re-Jeong-v4/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Guanxii1/Re-Jeong-v4?&style=social"></a>
<a href="https://github.com/Guanxii/Re-Jeong-v4/network/members"><img title="Fork" src="https://img.shields.io/github/forks/Guanxii1/Re-Jeong-v4?style=social"></a>
<a href="https://github.com/Guanxii1/Re-Jeong-v4/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Guanxii1/Re-Jeong-v4?label=Watching&style=social"></a>
</p>


  </p>
<p align="center"><img src="https://profile-counter.glitch.me/{Re-Jeong}/count.svg" alt="Re-Jeong-v4:: Visitor's Count"/></p>


  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&rainbow=true&scan=true" alt="Widget with the current Spotify song"  />
</div>


---


 ## SET-UP

## Fork

<h2 align="center">   

- ***You MUST `fork` this repo before fetching pairing code. Fork this repo by tapping  [`here`](https://github.com/Guanxii1/Re-jeong-v4/fork)***

**star✨ my repo if you like this bot🤖**


## Pairing:


- ***`Get your Creds.js` by  [`PAIRING CODE HERE`](https://taira-web-service.onrender.com).



- Then `Go-to WhatsApp > Three dots > Linked Devices`
   - You will get the creds.js file in your WhatsApp. Use trebedit to view it then copy.
 


## Heroku Setup:

   - ***[`CREATE HEROKU ACCOUNT`](https://signup.heroku.com/) `if you don't have one.`***


- ***Now [`DEPLOY TO HEROKU`](https://dashboard.heroku.com/new?template=https://github.com/Guanxii1/Re-Jeong-v4).***

-***`Paste your creds in the session folder 📁 Create new app,link it to your GitHub and deploy then start the worker.Or jus click deploy to heroku `***



***Tap the WhatsApp logo below to join our channel and group for updates***

<p align="left">
  <a aria-label="Join our channel for updates" href="https://whatsapp.com/channel/0029ValVRdpI1rcfS1rAJq3h" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>

<p align="left">
  <a aria-label="Join our group for updates" href="https://chat.whatsapp.com/DuQU3pbRi4s6kwd5SW5der" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/WA GROUP-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>


Incase of any issues, contact me  [here](https://wa.me/+27623649420) via WhatsApp.

Modifying the bot structure is at your own risk. We won't offer technical support if error occur.


## License

[MIT License](https://github.com/Guanxii1/Re-Jeong-v4/blob/main/LICENSE)

YOU WILL DIE🪦


